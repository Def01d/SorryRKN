from .utils import human_bytes

class _Stats:
    def __init__(self):
        self.reset()

    def reset(self):
        """Start Android connection counters without replacing shared object references."""
        self.connections_total = 0
        self.connections_active = 0
        self.connections_ws = 0
        self.connections_h2 = 0
        self.h2_tcp_connections = 0
        self.h2_requests = 0
        self.h2_errors = 0
        self.connections_tcp_fallback = 0
        self.connections_cfproxy = 0
        self.connections_fronting = 0
        self.connections_bad = 0
        self.connections_masked = 0
        self.ws_errors = 0
        self.bytes_up = 0
        self.bytes_down = 0
        self.pool_hits = 0
        self.pool_misses = 0
        self.cf_pool_hits = 0
        self.cf_pool_misses = 0
        self.media_stalls = 0
        self.media_pool_resets = 0
        self.last_media_stall = ''
        self.dc_connections = {}
        self.unavailable_dc = {}

    def summary(self) -> str:
        pool_total = self.pool_hits + self.pool_misses
        pool_s = (f"{self.pool_hits}/{pool_total}"
                  if pool_total else "n/a")
        cf_pool_total = self.cf_pool_hits + self.cf_pool_misses
        cf_pool_s = (f"{self.cf_pool_hits}/{cf_pool_total}"
                     if cf_pool_total else "n/a")
        return (f"total={self.connections_total} "
                f"active={self.connections_active} "
                f"ws={self.connections_ws} "
                f"h2={self.connections_h2} "
                f"h2_tcp={self.h2_tcp_connections} "
                f"h2_req={self.h2_requests} "
                f"h2_err={self.h2_errors} "
                f"tcp_fb={self.connections_tcp_fallback} "
                f"cf={self.connections_cfproxy} "
                f"front={self.connections_fronting} "
                f"bad={self.connections_bad} "
                f"masked={self.connections_masked} "
                f"err={self.ws_errors} "
                f"pool={pool_s} "
                f"cf_pool={cf_pool_s} "
                f"up={human_bytes(self.bytes_up)} "
                f"down={human_bytes(self.bytes_down)}")


stats = _Stats()
