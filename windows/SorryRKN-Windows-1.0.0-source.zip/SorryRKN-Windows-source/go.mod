module sorryrkn

go 1.24.0

require golang.org/x/sys v0.37.0
