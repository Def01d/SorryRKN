module sorryrkn

go 1.24.0

require golang.org/x/sys v0.37.0

require (
	golang.org/x/net v0.45.0
	golang.org/x/text v0.29.0 // indirect
)
